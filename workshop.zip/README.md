Instructions for this activity
1 - Make a new directory called "backup" - put it alongside a/ and b/
2 - Move all "old" zips in a/ and b/ into this newly created folder
